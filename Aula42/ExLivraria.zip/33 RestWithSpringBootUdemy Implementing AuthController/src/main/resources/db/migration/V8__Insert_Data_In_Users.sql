﻿INSERT INTO `users` (`user_name`, `full_name`, `password`, `account_non_expired`, `account_non_locked`, `credentials_non_expired`, `enabled`) VALUES
	('leandro', 'Leandro Costa', '$2a$16$9qr2tv0HmXbHBsx.TZFjfux742wCZM32a8Wi6iBqwIqaizlHPuxHS', b'1', b'1', b'1', b'1'),
	('Igor', 'Igor Aguiar', '$2a$16$h4yDQCYTy62R6xrtFDWONeMH3Lim4WQuU/aj8hxW.dJJoeyvtEkhK', b'1', b'1', b'1', b'1'),
	('bruno'  , 'Bruno Sabia', '$2a$16$oAiRaXiR03Hs7vkgA0Vsn.Q9nL1lhUchBpZ3i4ttY8cKyr2mtaouu', b'1', b'1', b'1', b'1');